const OneFrameTime = 17;

const createDiv: (
	classList: string[],
	children?: HTMLElement[]
) => HTMLElement = (classList, children = []) => {
	const div = document.createElement("div");
	div.classList.add(...classList);
	children.forEach((ele) => {
		div.appendChild(ele);
	});
	return div;
};

const createElementNS: (name: string, attr: { [key: string]: any }) => any = (
	name,
	attr
) => {
	const xmlns = "http://www.w3.org/2000/svg";
	const elementNS = document.createElementNS(xmlns, name);
	Object.keys(attr).forEach((key) => {
		elementNS.setAttributeNS(null, key, attr[key]);
	});
	return elementNS;
};

class Marble {
	constructor({ color = `#ff2244` }) {
		this.Color = color;
		this.DOM.style.backgroundColor = this.Color;
		this.DOM.style.width = `${Marble.Size}px`;
		this.DOM.style.height = `${Marble.Size}px`;
	}
	static readonly Size = 60;
	readonly ID = `${(~~(Math.random() * 1000000000))
		.toString(16)
		.toLocaleUpperCase()}`;
	readonly DOM: HTMLElement = createDiv(["marble"]);
	readonly Color: string;
	parent: HTMLElement | null;
	x: number;
	y: number;

	setPosition(x: number, y: number): Marble {
		this.x = x;
		this.y = y;
		if (this.DOM) {
			this.DOM.style.transform = `translate(calc(${this.x}px - 50%), calc(${this.y}px - 50%))`;
		}
		return this;
	}

	appendTo(parent: HTMLElement): Marble {
		this.parent = parent;
		parent.appendChild(this.DOM);
		return this;
	}

	remove(): Marble {
		if (!this.parent) {
			return this;
		}
		this.parent.removeChild(this.DOM);
		this.parent = null;
		return this;
	}

	overlap(marble: Marble): number {
		let r =
			Marble.Size - Math.sqrt((this.x - marble.x) ** 2 + (this.y - marble.y) ** 2);
		return r;
	}
}

interface MarbleData {
	marble: Marble;
	percent: number;
}

interface MarbleBoomData {
	marble: Marble;
	speed: { x: number; y: number };
}

class Player {
	constructor({ x = 0, y = 0 }) {
		this.X = x;
		this.Y = y;
		this.DOM.style.transform = `translate(calc(${this.X}px - 50%), calc(${this.Y}px - 50%)) rotate(0deg)`;
	}
	readonly Marble: HTMLElement = createDiv(["marble-1"]);
	readonly NextMarbleList: HTMLElement[] = [
		createDiv(["marble-2"]),
		createDiv(["marble-2"]),
		createDiv(["marble-2"])
	];
	readonly DOM: HTMLElement = createDiv(
		["player"],
		[this.Marble, ...this.NextMarbleList]
	);
	readonly X: number;
	readonly Y: number;

	private parent: HTMLElement;
	private lookX: number;
	private lookY: number;
	private rotate: number;

	lookAt(x: number, y: number): Player {
		if (!this.parent) {
			return this;
		}
		this.lookX = x;
		this.lookY = y;
		const rect = this.DOM.getBoundingClientRect();
		const innerX = rect.left + (rect.right - rect.left) / 2;
		const innerY = rect.top + (rect.bottom - rect.top) / 2;
		this.rotate =
			(Math.atan2(this.lookY - innerY, this.lookX - innerX) * 180) / Math.PI + 90;
		this.DOM.style.transform = `translate(calc(${this.X}px - 50%), calc(${this.Y}px - 50%)) rotate(${this.rotate}deg)`;
		return this;
	}
	appendTo(parent: HTMLElement): Player {
		this.parent = parent;
		this.parent.appendChild(this.DOM);
		return this;
	}
	setMarbleColor(color: string): Player {
		this.Marble.style.backgroundColor = color;
		return this;
	}
	setNextMarbleColor(color: string): Player {
		this.NextMarbleList.forEach((dom) => {
			dom.style.backgroundColor = color;
		});
		return this;
	}
	getVector() {
		const innerRotate = this.rotate - 90;
		return {
			x: Math.cos((innerRotate * Math.PI) / 180) * 30,
			y: Math.sin((innerRotate * Math.PI) / 180) * 30
		};
	}
}

class Zuma {
	constructor(data: {
		width: number;
		height: number;
		path: string;
		scale: number;
		playerPos: { x: number; y: number };
		updateScore?: (score: number) => void;
		updateFinal?: (isFinal: boolean) => void;
	}) {
		this.width = data.width;
		this.height = data.height;
		const svg: SVGSVGElement = createElementNS("svg", {
			x: "0px",
			y: "0px",
			width: `${data.width}px`,
			height: `${data.height}px`,
			viewBox: `0 0 ${data.width} ${data.height}`
		});
		svg.appendChild(this.Path);
		this.Path.setAttributeNS(null, "d", data.path);
		this.PathLength = this.Path.getTotalLength();

		const startHolePos = this.Path.getPointAtLength(0);
		const finalHolePos = this.Path.getPointAtLength(this.PathLength);
		const startHole = createDiv(["start-hole"]);
		const finalHole = createDiv(["final-hole"]);
		startHole.style.left = `${startHolePos.x}px`;
		startHole.style.top = `${startHolePos.y}px`;
		finalHole.style.left = `${finalHolePos.x}px`;
		finalHole.style.top = `${finalHolePos.y}px`;
		this.Container.appendChild(startHole);
		this.Container.appendChild(finalHole);

		this.Container.style.width = `${data.width}px`;
		this.Container.style.height = `${data.height}px`;
		this.Container.style.transform = `scale(${data.scale || 1})`;
		this.Player = new Player(data.playerPos);
		this.Player.appendTo(this.Container);
		this.colorList = [...Zuma.DefaultColorList];
		this.colorList.forEach((color) => {
			this.marbleColorCount[color] = 0;
		});
		this.updateScore = data.updateScore;
		this.updateFinal = data.updateFinal;
	}
	static readonly DefaultColorList = [
		"#0C3406",
		"#077187",
		"#74A57F",
		"#ABD8CE",
		"#E4C5AF"
	];
	private readonly updateScore: undefined | ((score: number) => void);
	private readonly updateFinal: undefined | ((isFinal: boolean) => void);
	private readonly width: number;
	private readonly height: number;
	private readonly AllMarbleLength = 100;
	private readonly InitMarbleLength = 20;
	private readonly Container: HTMLElement = createDiv(
		["container"],
		[
			createDiv(["leaf", "leaf-01"]),
			createDiv(["leaf", "leaf-02"]),
			createDiv(["leaf", "leaf-03"]),
			createDiv(["leaf", "leaf-04"]),
			createDiv(["leaf", "leaf-05"]),
			createDiv(["leaf", "leaf-06"])
		]
	);
	private readonly Path: SVGPathElement = createElementNS("path", {});
	private readonly PathLength: number;
	private parent: HTMLElement;
	private moveSpeed: number = 4;
	private autoAddMarbleCount = 0;
	private marbleDataList: MarbleData[] = [];
	private marbleBoomList: MarbleBoomData[] = [];
	private marbleColorCount = {};
	private time: number;
	private moveTimes: number = 0;
	private colorList: string[];
	private isStart = false;
	private _isInit = false;
	private _isFinal = false;
	private windowEventList: { name: string; fn: (...e) => void }[] = [];
	private checkDeleteAfterTouchData: { [marbleId: string]: boolean } = {};

	private readonly Player: Player;
	private playerMarble: {
		now: Marble | null;
		next: Marble | null;
	} = {
		now: null,
		next: null
	};

	private _score = 0;

	get isInit(): boolean {
		return this._isInit;
	}

	set isFinal(isFinal: boolean) {
		this._isFinal = isFinal;
		this.updateFinal && this.updateFinal(this._isFinal);
	}
	get isFinal(): boolean {
		return this._isFinal;
	}

	set score(score: number) {
		this._score = score;
		this.updateScore && this.updateScore(this._score);
	}
	get score(): number {
		return this._score;
	}

	start(): Zuma {
		this.isStart = true;
		this.time = new Date().getTime();
		if (!this.windowEventList.length) {
			this.bindEvent();
		}
		this.animation();
		return this;
	}

	stop(): Zuma {
		this.isStart = false;
		return this;
	}

	reset(): Zuma {
		this.isStart = false;
		this._isInit = false;
		this.isFinal = false;
		this.autoAddMarbleCount = 0;
		this.score = 0;
		this.moveSpeed = 4;
		this.colorList = [...Zuma.DefaultColorList];
		this.marbleDataList.forEach((d) => d.marble.remove());
		this.marbleBoomList.forEach((d) => d.marble.remove());
		this.marbleDataList.length = 0;
		this.marbleBoomList.length = 0;
		this.checkDeleteAfterTouchData = {};
		this.playerMarble.now = null;
		this.playerMarble.next = null;
		this.Player.setMarbleColor("").setNextMarbleColor("");
		Object.keys(this.marbleColorCount).forEach((color) => {
			this.marbleColorCount[color] = 0;
		});
		return this;
	}

	destroy(): void {
		this.reset();
		if (this.parent) {
			this.parent.removeChild(this.Container);
		}
		this.windowEventList.forEach((d) => {
			window.removeEventListener(d.name, d.fn);
		});
		this.windowEventList = [];
	}

	appendTo(parent: HTMLElement): Zuma {
		this.parent = parent;
		this.parent.appendChild(this.Container);
		return this;
	}

	private attack(): Zuma {
		if (!this.Player || !this.playerMarble.now || !this.playerMarble.next) {
			return this;
		}
		const vector = this.Player.getVector();
		this.marbleBoomList.push({
			marble: this.playerMarble.now,
			speed: vector
		});
		this.playerMarble.now.appendTo(this.Container);
		this.playerMarble.now.setPosition(this.Player.X, this.Player.Y);
		this.playerMarble.now = this.playerMarble.next;
		this.playerMarble.next = this.createMarble();
		this.Player.setMarbleColor(this.playerMarble.now.Color).setNextMarbleColor(
			this.playerMarble.next.Color
		);
		return this;
	}

	private init(): Zuma {
		const innerTime = new Date().getTime();
		if (this.marbleDataList.length >= this.InitMarbleLength && this.isStart) {
			this._isInit = true;
			this.moveSpeed = 20;
			this.moveTimes = this.moveSpeed;
			this.playerMarble.now = this.createMarble();
			this.playerMarble.next = this.createMarble();
			this.Player.setMarbleColor(this.playerMarble.now.Color).setNextMarbleColor(
				this.playerMarble.next.Color
			);
			return this;
		}
		if (innerTime - this.time < OneFrameTime * 4) {
			return this;
		}
		this.time = innerTime;
		this.unshiftMarble();
		return this;
	}

	private moveMoveMarbleData(): void {
		const firstMarble = this.marbleDataList[0];
		if (!firstMarble) {
			return;
		}
		if (firstMarble.percent >= 0.99) {
			this.score -= 1;
			this.removeMarbleFromDataList(firstMarble.marble);
		}
		const moveNum = Marble.Size / this.moveSpeed;
		firstMarble.percent += moveNum / this.PathLength;
		const pos = this.Path.getPointAtLength(firstMarble.percent * this.PathLength);
		firstMarble.marble.setPosition(pos.x, pos.y);

		let prevMarble: MarbleData = firstMarble;
		const deleteList: Marble[] = [];
		for (let i = 1; i < this.marbleDataList.length; i++) {
			const marbleData = this.marbleDataList[i];
			if (marbleData.percent >= 0.99) {
				this.score -= 1;
				this.removeMarbleFromDataList(marbleData.marble, i);
				continue;
			}
			const overlap = prevMarble.marble.overlap(marbleData.marble);
			if (overlap > 0 || prevMarble.percent > marbleData.percent) {
				// 檢查退回後修不需要刪除
				if (this.checkDeleteAfterTouchData[marbleData.marble.ID]) {
					delete this.checkDeleteAfterTouchData[marbleData.marble.ID];
					if (marbleData.marble.Color === prevMarble.marble.Color) {
						const list = this.getNeerSameMarble(marbleData.marble);
						if (list.length >= 3) {
							deleteList.push(...list);
						}
					}
				}
				if (prevMarble.percent > marbleData.percent) {
					marbleData.percent = prevMarble.percent + Marble.Size / this.PathLength;
				} else {
					marbleData.percent += overlap / this.PathLength;
				}
			} else if (overlap < -5 && marbleData.percent > prevMarble.percent) {
				if (overlap < -Marble.Size) {
					this.checkDeleteAfterTouchData[marbleData.marble.ID] = true;
				}
				const moveNum = (Marble.Size / this.moveSpeed) * 4;
				marbleData.percent -= moveNum / this.PathLength;
			}
			const pos = this.Path.getPointAtLength(marbleData.percent * this.PathLength);
			marbleData.marble.setPosition(pos.x, pos.y);
			prevMarble = marbleData;
		}
		deleteList.forEach((marble) => {
			this.score += 3;
			this.removeMarbleFromDataList(marble);
		});
	}

	private moveMoveMarbleBoom(): void {
		if (!this.marbleBoomList.length) {
			return;
		}

		// TODO: 有空優化成分區檢測
		const marbleDataList = this.marbleDataList;
		const deleteData: (MarbleBoomData & { isMove: boolean })[] = [];
		this.marbleBoomList.forEach((data) => {
			data.marble.setPosition(
				data.marble.x + data.speed.x,
				data.marble.y + data.speed.y
			);
			for (let i = 0; i < marbleDataList.length; i++) {
				const marbleData = marbleDataList[i];
				const overlap = data.marble.overlap(marbleData.marble);
				if (overlap > 5) {
					if (data.marble.Color === marbleData.marble.Color) {
						const sameList = this.getNeerSameMarble(marbleData.marble);
						if (sameList.length >= 2) {
							this.score += sameList.length;
							sameList.forEach((marble) => {
								this.removeMarbleFromDataList(marble);
							});
							deleteData.push({ ...data, isMove: false });
							return;
						}
					}
					this.addMarbleToNeer(data.marble, marbleData);
					deleteData.push({ ...data, isMove: true });
					return;
				}
			}
			if (
				Math.abs(data.marble.x) > this.width ||
				Math.abs(data.marble.y) > this.height
			) {
				deleteData.push({ ...data, isMove: false });
			}
		});
		deleteData.forEach((date) => {
			const index = this.marbleBoomList.findIndex(
				(d) => d.marble.ID === date.marble.ID
			);
			this.marbleBoomList.splice(index, 1);
			if (!date.isMove) {
				date.marble.remove();
				this.marbleColorCount[date.marble.Color]--;
			}
		});
	}

	private removeMarbleFromDataList(
		marble: Marble,
		index = this.marbleDataList.findIndex((d) => d.marble.ID === marble.ID)
	): Zuma {
		delete this.checkDeleteAfterTouchData[marble.ID];
		this.marbleDataList[index].marble.remove();
		this.marbleDataList.splice(index, 1);
		this.marbleColorCount[marble.Color]--;
		return this;
	}

	private addMarbleToNeer(marble: Marble, target: MarbleData): Zuma {
		const index = this.marbleDataList.findIndex(
			(d) => d.marble.ID === target.marble.ID
		);
		const prevPos = this.Path.getPointAtLength(
			(target.percent - Marble.Size / this.PathLength) * this.PathLength
		);
		const nextPos = this.Path.getPointAtLength(
			(target.percent + Marble.Size / this.PathLength) * this.PathLength
		);
		const prevGap = (prevPos.x - marble.x) ** 2 + (prevPos.y - marble.y) ** 2;
		const nextGap = (nextPos.x - marble.x) ** 2 + (nextPos.y - marble.y) ** 2;
		if (prevGap < nextGap) {
			this.marbleDataList.splice(index - 1, 0, {
				marble,
				percent: target.percent - Marble.Size / this.PathLength / 2
			});
		} else {
			this.marbleDataList.splice(index, 0, {
				marble,
				percent: target.percent + Marble.Size / this.PathLength / 2
			});
		}
		return this;
	}

	private createMarble(): Marble {
		const marble = new Marble({ color: this.getColor() });
		this.marbleColorCount[marble.Color]++;
		return marble;
	}

	private unshiftMarble(): Zuma {
		const marble = this.createMarble();
		marble.appendTo(this.Container);
		this.marbleDataList.unshift({
			marble,
			percent: 0
		});
		this.autoAddMarbleCount++;
		return this;
	}

	private getColor(): string {
		const index = ~~(Math.random() * this.colorList.length);
		const color = this.colorList[index];
		if (
			this.marbleColorCount[color] ||
			this.colorList.length === 1 ||
			!this.isInit
		) {
			return color;
		}
		this.colorList.splice(index, 1);
		return this.getColor();
	}

	private getNeerSameMarble(marble: Marble): Marble[] {
		let checkMarble: Marble;
		const index = this.marbleDataList.findIndex(
			(ele) => ele.marble.ID === marble.ID
		);
		const neerList: Marble[] = [marble];

		checkMarble = marble;
		for (let i = index + 1; i < this.marbleDataList.length; i++) {
			const nowMarble = this.marbleDataList[i].marble;
			if (
				nowMarble.Color === checkMarble.Color &&
				nowMarble.overlap(checkMarble) > Marble.Size / -10
			) {
				checkMarble = nowMarble;
				neerList.push(nowMarble);
			} else {
				break;
			}
		}
		checkMarble = marble;
		for (let i = index - 1; i >= 0; i--) {
			const nowMarble = this.marbleDataList[i].marble;
			if (
				nowMarble.Color === checkMarble.Color &&
				nowMarble.overlap(checkMarble) > Marble.Size / -10
			) {
				checkMarble = nowMarble;
				neerList.push(nowMarble);
			} else {
				break;
			}
		}
		return neerList;
	}

	private animation(): void {
		if (!this.isStart) {
			return;
		}
		requestAnimationFrame(() => this.animation());
		if (!this.isInit) {
			this.init().moveMoveMarbleData();
			return;
		}
		const innerTime = new Date().getTime();
		if (innerTime - this.time < OneFrameTime) {
			return;
		}
		this.time = innerTime;
		if (
			this.moveTimes === this.moveSpeed &&
			this.autoAddMarbleCount < this.AllMarbleLength
		) {
			this.unshiftMarble();
			this.moveTimes = 0;
		}
		this.moveMoveMarbleBoom();
		this.moveMoveMarbleData();
		this.moveTimes++;
		if (this.marbleDataList.length === 0) {
			this.isFinal = true;
		}
	}

	private bindEvent(): void {
		const mousemove = (e: MouseEvent) => {
			if (!this.Player) {
				return;
			}
			this.Player.lookAt(e.pageX, e.pageY);
		};
		const click = (e: MouseEvent) => {
			if (!this.isStart || this.isFinal || !this.isInit) {
				return;
			}
			this.attack();
			if (e.button === 1) {
			}
		};
		const keydown = (e: KeyboardEvent) => {
			if (!this.isStart || this.isFinal || !this.isInit) {
				return;
			}
			if (e.code === "Space") {
				e.preventDefault();
				if (this.Player && this.playerMarble.now && this.playerMarble.next) {
					[this.playerMarble.now, this.playerMarble.next] = [
						this.playerMarble.next,
						this.playerMarble.now
					];
					this.Player.setMarbleColor(this.playerMarble.now.Color).setNextMarbleColor(
						this.playerMarble.next.Color
					);
				}
			}
		};
		window.addEventListener("mousemove", mousemove);
		window.addEventListener("click", click);
		window.addEventListener("keydown", keydown);
		this.windowEventList.push(
			{ name: "mousemove", fn: mousemove },
			{ name: "click", fn: click },
			{ name: "keydown", fn: keydown }
		);
	}
}

window.onload = () => {
	const scoreDOM: HTMLElement = document.body.querySelector(
		"#score .num"
	) as HTMLElement;
	const startPopup: HTMLElement = document.body.querySelector(
		"#start"
	) as HTMLElement;
	const stopPopup: HTMLElement = document.body.querySelector(
		"#stop"
	) as HTMLElement;
	const finalPopup: HTMLElement = document.body.querySelector(
		"#final"
	) as HTMLElement;
	const finalNum: HTMLElement = finalPopup.querySelector(".num") as HTMLElement;

	const zumaGame = new Zuma({
		width: 1200,
		height: 800,
		scale: 0.7,
		path: `M235.5-36.5c0,0-129,157.858-143,381.918c-6.6,105.632,47,236.043,159,295.679s338.566,101.881,547,64.404
    c199-35.781,312.016-164.676,313-266c1-103-34-221.816-200-278.044c-142.542-48.282-346.846-37.455-471,31.044
    c-116,64-154.263,213.533-81,304.619c92,114.381,410,116.381,476,2.891c62.975-108.289-40-203.51-158-206.51`,
		playerPos: { x: 550, y: 400 },
		updateScore: (score: number) => {
			scoreDOM.innerHTML = `${score}`;
		},
		updateFinal: (isFinal: boolean) => {
			if (isFinal) {
				finalPopup.classList.add("active");
				finalNum.innerHTML = `${zumaGame.score}`;
			}
		}
	});
	zumaGame.appendTo(document.body);

	(startPopup.querySelector(".button") as HTMLElement).addEventListener(
		"click",
		() => {
			startPopup.classList.remove("active");
			zumaGame.start();
		}
	);
	(stopPopup.querySelector("#start-btn") as HTMLElement).addEventListener(
		"click",
		() => {
			stopPopup.classList.remove("active");
			setTimeout(() => {
				zumaGame.start();
			}, 100);
		}
	);
	(stopPopup.querySelector("#reset-btn") as HTMLElement).addEventListener(
		"click",
		() => {
			stopPopup.classList.remove("active");
			zumaGame.reset().start();
		}
	);
	(finalPopup.querySelector(".button") as HTMLElement).addEventListener(
		"click",
		() => {
			finalPopup.classList.remove("active");
			zumaGame.reset().start();
		}
	);
	window.addEventListener("keydown", (e) => {
		if (e.code === "Escape" && zumaGame.isInit) {
			zumaGame.stop();
			stopPopup.classList.add("active");
		}
	});
	// ═══════════════════════════════════════════════════════════
	// AllinONE 平台协议集成层 — 道具兑换 & UGC 道具接入
	// ═══════════════════════════════════════════════════════════

	// 暴露游戏实例，供 AllinONE Effect Engine 和 UGC 道具访问
	(window as any).zumaGame = zumaGame;

	// 效果状态
	let scoreMultiplier = 1;
	let speedReduction = 0;

	// 重写 score setter 以支持分数倍率
	const _origScoreSetter = Object.getOwnPropertyDescriptor(
		Zuma.prototype, 'score'
	);
	if (_origScoreSetter && _origScoreSetter.set) {
		const _origSet = _origScoreSetter.set;
		const _origGet = _origScoreSetter.get!;
		Object.defineProperty(Zuma.prototype, 'score', {
			get: _origGet,
			set: function(this: Zuma, val: number) {
				if (scoreMultiplier !== 1 && val > this.score) {
					val = Math.floor(val * scoreMultiplier);
				}
				_origSet.call(this, val);
			},
		});
	}

	// 内置效果处理器（适配 Zuma 游戏机制）
	const zumaEffects: { [key: string]: (data: any) => void } = {
		score_boost: (data) => {
			scoreMultiplier = (data.effects && data.effects.multiplier) || 2;
			console.log('[Zuma SDK] 分数倍率已激活: x' + scoreMultiplier);
		},
		difficulty_reducer: (data) => {
			const mult = (data.effects && data.effects.multiplier) || 0.6;
			speedReduction = Math.floor(zumaGame['moveSpeed'] * (1 - mult));
			(zumaGame as any).moveSpeed = Math.max(1, (zumaGame as any).moveSpeed - speedReduction);
			console.log('[Zuma SDK] 难度已降低, 速度: ' + (zumaGame as any).moveSpeed);
		},
		extra_life: (data) => {
			const lives = (data.effects && data.effects.lives) || 1;
			zumaGame.score += lives * 50;
			console.log('[Zuma SDK] 额外生命: +' + (lives * 50) + ' 分');
		},
		time_bonus: (data) => {
			const bonus = (data.effects && data.effects.bonusTime) || 30;
			// 清除路径上最后 N 个弹珠作为奖励
			const list = (zumaGame as any).marbleDataList;
			const removeCount = Math.min(list.length, Math.ceil(bonus / 5));
			for (let i = 0; i < removeCount; i++) {
				if (list.length > 0) {
					const last = list[list.length - 1];
					last.marble.remove();
					list.pop();
				}
			}
			console.log('[Zuma SDK] 时间奖励: 清除 ' + removeCount + ' 个弹珠');
		},
		speed_boost: (data) => {
			const mult = (data.effects && data.effects.multiplier) || 1.5;
			(zumaGame as any).moveSpeed = Math.floor((zumaGame as any).moveSpeed * mult);
			console.log('[Zuma SDK] 速度提升: ' + (zumaGame as any).moveSpeed);
		},
	};

	// ── 方式 A：监听 AllinONE SDK 的 CustomEvent（兑换码兑换）──
	window.addEventListener('allinone-item-redeemed', function(e: any) {
		const detail = e.detail;
		console.log('[Zuma SDK] 道具已兑换:', detail.itemName, detail.effectType);
		const handler = zumaEffects[detail.effectType];
		if (handler) {
			handler(detail);
		} else {
			console.log('[Zuma SDK] 未知效果类型:', detail.effectType);
		}
	});

	// ── 方式 B：监听 EXTENSION_VOUCHER（UGC 道具下发）──
	// effectCode 沙箱引擎（遵循 AllinONE 安全规范）
	const ugcItems: any[] = [];
	const effectHandlers: { [key: string]: Function } = {};
	const effectSandbox = {
		game: zumaGame,
		scoreMultiplier: () => scoreMultiplier,
		addScore: (n: number) => { zumaGame.score += n; },
		getMarbleCount: () => (zumaGame as any).marbleDataList.length,
		Math: Math,
		console: console,
	};

	function registerDynamicEffect(effectName: string, effectCodeStr: string): boolean {
		if (effectHandlers[effectName]) return true;
		if (!effectCodeStr || typeof effectCodeStr !== 'string') return false;
		if (effectCodeStr.length > 4000) return false;
		const blocked = [
			'eval(', 'new function', 'import(', 'require(', '__proto__',
			'prototype', 'constructor', 'window.', 'document.',
			'parent.', 'top.', 'globalthis', 'self.',
			'fetch(', 'xmlhttprequest', 'websocket', 'worker(',
			'localstorage', 'sessionstorage', 'cookie',
		];
		const lowerCode = effectCodeStr.toLowerCase();
		for (const b of blocked) {
			if (lowerCode.indexOf(b) !== -1) {
				console.warn('[Zuma SDK] effectCode 安全检查失败:', b);
				return false;
			}
		}
		try {
			const sandboxKeys = Object.keys(effectSandbox);
			const sandboxVals = sandboxKeys.map((k) => (effectSandbox as any)[k]);
			const sandboxFn = new Function(
				...sandboxKeys,
				'return (' + effectCodeStr + ');'
			);
			const rawHandler = sandboxFn.apply(null, sandboxVals);
			if (typeof rawHandler !== 'function') return false;
			effectHandlers[effectName] = function() {
				try { return rawHandler.apply(null, arguments); }
				catch(e) { console.error('[Zuma SDK] 效果执行失败:', e); return null; }
			};
			console.log('[Zuma SDK] 动态效果已注册:', effectName);
			return true;
		} catch(e) {
			console.error('[Zuma SDK] effectCode 编译失败:', e);
			return false;
		}
	}

	window.addEventListener('message', function(e) {
		if (e.data && e.data.type === 'EXTENSION_VOUCHER') {
			const v = e.data.voucher;
			if (!v || !v.data) return;
			const data = v.data;

			// 自定义效果道具（effectCode）
			if (data.effectCode) {
				registerDynamicEffect(data.effect, data.effectCode);
				ugcItems.push({
					id: v.id, name: data.name, effect: data.effect,
					params: data.params, effectCode: data.effectCode,
				});
				console.log('[Zuma SDK] UGC自定义道具到账:', data.name);
				// 立即执行一次效果
				if (effectHandlers[data.effect]) {
					effectHandlers[data.effect](data.params || {});
				}
			}
			// 普通数据道具
			else if (data.effect) {
				console.log('[Zuma SDK] UGC数据道具到账:', data.name, data.effect);
				// 尝试用内置效果处理
				const handler = zumaEffects[data.effect];
				if (handler) {
					handler({ effects: data.params || {} });
				} else {
					// 默认加 100 分
					zumaGame.score += 100;
					console.log('[Zuma SDK] 默认效果: +100 分');
				}
			}
		}
	});

	// 使用 AllinONE SDK API（如果平台已注入）
	if ((window as any).AllinONE) {
		(window as any).AllinONE.onItemRedeemed(function(detail: any) {
			console.log('[Zuma SDK] SDK API 道具回调:', detail.itemName);
			const handler = zumaEffects[detail.effectType];
			if (handler) handler(detail);
		});
	}

	console.log('[Zuma SDK] AllinONE 协议集成就绪 ✅');

	window.addEventListener("blur", function (e) {
		if (zumaGame.isInit && !zumaGame.isFinal) {
			zumaGame.stop();
			stopPopup.classList.add("active");
		}
	});
};
