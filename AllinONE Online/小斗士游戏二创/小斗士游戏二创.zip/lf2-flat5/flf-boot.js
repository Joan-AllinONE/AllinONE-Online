(function () {

    if (document.getElementById('flf-config')) {
        var flf_config = document.getElementById('flf-config').innerHTML;
        flf_config = JSON.parse(flf_config);
        requirejs.config({
            baseUrl: flf_config.root || '',
            // 别名：既支持 'third_party/random' 也支持平台可能归一化的裸 'random'
            paths: { random: 'third_party/random' },
            config: {}
        });
    }

    requirejs([
        'core/support', 'LF/loader!' + flf_config.package, 'LF/manager',
        'LF/util', 'LF/factories', 'LF/global', './buildinfo.js', 'core/css!LF/application.css'
    ], function (Fsupport, package, Manager, util, Factory, Global, buildinfo) {

        if (typeof (console) === 'undefined') {
            console = {};
            console.log = console.error = console.info = console.debug = console.warn = console.trace = console.dir = console.dirxml = console.group = console.groupEnd = console.time = console.timeEnd = console.assert = console.profile = function () { };
        }

        console.log(util.div('projectFmessage').innerHTML);

        if (flf_config.package.indexOf('http') === 0) {
            package.path = flf_config.package;
            package.location = flf_config.package;
        } else {
            package.path = util.normalize_path(flf_config.package);
            package.location = util.normalize_path(flf_config.root + flf_config.package);
        }

        // analytics disabled for local/offline use

        util.div('window_caption_title').innerHTML = buildinfo.version;

        var manager = new Manager(package, buildinfo);

        /* =========================================================
         * AllinONE 控制接口 (exposed to window.myGame)
         * 让 AllinONE 道具效果（武器/无敌/回血/召唤等）能直接操控 F.LF 游戏
         * ========================================================= */
        var CHAR_NAME = { deep: 1, john: 2, henry: 4, rudolf: 5, louis: 6, firen: 7, freeze: 8, dennis: 9, woody: 10, davis: 11, bandit: 30 };
        var WEAPON_NAME = { stick: 100, hoe: 101, stone: 150, wooden_box: 151, ice_sword: 213 };

        function getMatch() {
            return (manager && manager.match) ? manager.match : null;
        }
        function getPlayers() {
            var m = getMatch(), list = [];
            if (!m || !m.character) return list;
            for (var uid in m.character) {
                var c = m.character[uid];
                if (c && c.type === 'character' && !c.is_npc) list.push(c);
            }
            return list;
        }
        function resolveId(map, v) {
            if (typeof v === 'number') return v;
            if (typeof v === 'string') {
                if (map[v] !== undefined) return map[v];
                var n = parseInt(v, 10);
                if (!isNaN(n)) return n;
            }
            return null;
        }
        function giveWeapon(char, weaponId) {
            var m = getMatch();
            if (!m || !char) return false;
            var OBJ = util.select_from(m.data.object, { id: weaponId });
            if (!OBJ || !OBJ.data || !Factory[OBJ.type]) return false;
            if (char.hold && char.hold.obj) { try { char.drop_weapon(0, 0); } catch (e) {} }
            var wea = new Factory[OBJ.type]({ match: m, team: char.team }, OBJ.data, weaponId);
            wea.init({ opoint: { kind: 2 }, parent: char });
            return true;
        }
        function spawn(opts) {
            var m = getMatch();
            if (!m) return false;
            opts = opts || {};
            var players = getPlayers();
            var humanTeam = players.length ? players[0].team : 0;
            var team;
            if (typeof opts.team === 'number') team = opts.team;
            else if (opts.relation === 'ally') team = humanTeam;
            else team = (humanTeam + 1) % 4;
            var id = resolveId(CHAR_NAME, opts.id != null ? opts.id : 'bandit');
            if (id == null) id = 30;
            var count = opts.count || 1;
            var hp = opts.hp || 100;
            var list = [];
            for (var i = 0; i < count; i++) {
                list.push({
                    name: opts.name || '+man',
                    controller: { type: 'AIscript', id: opts.ai || 4 },
                    type: 'computer',
                    id: id,
                    team: team,
                    pos: { x: 400 + i * 40, y: 0, z: 0 },
                    spec: { is_npc: true, health: { hp: hp, hp_full: hp, hp_bound: hp, mp: 100, mp_full: 100 }, parent: null }
                });
            }
            // ensure the character data AND its AI script are loaded, then spawn
            // 注意 1：util.organize_package 已在游戏启动时(manager.js)对完整数据包跑过一次，
            // 为每个角色建好了特殊招式依赖包(.pack)。此处 m.data === config.package.data，
            // 若再传 m.data 给 organize_package，它会去读 m.data.data.object 而 m.data.data 为 undefined，
            // 导致 util.js:169 "Cannot read properties of undefined (reading 'object')" 崩溃。故不可再调。
            // 注意 2：AI 文件夹是懒加载的(loader-config.js)，开局时 match.js 会用 data.load({AI: AI_ids})
            // 把用到的 AI 脚本加载成构造函数。spawn 新增的角色若仅加载 object 而不加载对应 AI，
            // 则 $.data.AI[id].data 仍是字符串 'lazy'，create_characters 里 new AIcontroller(...) 会报
            // "AIcontroller is not a constructor"。因此这里必须把角色用到的 AI id 一起加载。
            var aiIds = [];
            for (var k = 0; k < list.length; k++) {
                var aid = list[k].controller.id;
                if (aiIds.indexOf(aid) === -1) aiIds.push(aid);
            }
            // 注意 3：特殊招式(specialattack)与角色(character)一样是【懒加载】的(loader-config.js)。
            // 正常开局 match.js:41 会把初始角色的 .pack 特殊招式 id 并进 object_ids 预加载；
            // 但 spawn 出的新角色(如 davis)其 .pack 特殊招式从未被加载，仍是字符串 'lazy'。
            // 一旦它放招，character.js:2007 → create_multiple_objects → match.js:310 会直接用 OBJ.data
            // 实例化 specialattack，得到 new factory.specialattack(config, 'lazy', id) → 崩溃。
            // 因此必须把该角色 .pack 里的特殊招式 id 也并入 object 加载列表（特殊招式同属 $.data.object）。
            var objIds = [id];
            var charEntry = util.select_from(m.data.object, { id: id });
            if (charEntry && charEntry.pack) {
                for (var p = 0; p < charEntry.pack.length; p++) {
                    var pid = charEntry.pack[p].id;
                    if (objIds.indexOf(pid) === -1) objIds.push(pid);
                }
            }
            if (m.data && typeof m.data.load === 'function') {
                m.data.load({ object: objIds, AI: aiIds }, function () {
                    m.create_non_player_characters(list);
                });
            } else {
                m.create_non_player_characters(list);
            }
            return true;
        }

        window.myGame = {
            manager: manager,
            getMatch: getMatch,
            getPlayers: getPlayers,
            giveWeapon: giveWeapon,
            setInvincible: function (char, on) { if (char && char.health) char.health.invincible = !!on; },
            heal: function (char, amount) {
                if (!char || !char.health) return;
                var cap = (char.health.hp_bound != null) ? char.health.hp_bound : 100;
                char.health.hp = Math.min(cap, (char.health.hp || 0) + (amount || 0));
            },
            restoreMp: function (char, amount) {
                if (!char || !char.health) return;
                var cap = char.health.mp_full || 100;
                char.health.mp = Math.min(cap, (char.health.mp || 0) + (amount || 0));
            },
            spawn: spawn,
            // 必杀/特招：让角色直接进入对应动画帧（等效于"按出"该招，复用引擎 combo→帧→opoint 链路）
            comboTag: (Global && Global.combo_tag) ? Global.combo_tag : {},
            performSpecial: function (char, comboToken) {
                if (!char || !char.frame || !char.frame.D) return false;
                // 必杀通常需要内力，补足以确保能放出
                if (char.health) {
                    char.health.mp = (char.health.mp_full != null) ? char.health.mp_full : 100;
                }
                var tag = (Global && Global.combo_tag && Global.combo_tag[comboToken]) || null;
                if (!tag) return false;
                // combo 标签几乎定义在每个帧上；当前帧没有则回退到站立帧(frame 0)
                var target = char.frame.D[tag];
                if (target == null && char.data && char.data.frame && char.data.frame[0]) {
                    target = char.data.frame[0][tag];
                }
                if (target == null) return false;
                char.trans.frame(target, 11);
                return true;
            }
        };

        // notify AllinONE adapter that the game bridge is ready
        window.dispatchEvent(new CustomEvent('lf2-ready', { detail: { myGame: window.myGame } }));

    });

}());
