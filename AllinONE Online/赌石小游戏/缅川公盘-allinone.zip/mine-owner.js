/* ================================================================
   mine-owner.js — 矿主经营系统（独立模块，不侵入游戏主逻辑）
   ----------------------------------------------------------------
   规则：玩家设计的矿区（m.ext 扩展矿区）入场即认领为矿主产业。
   经营玩法：矿脉升级（出绿率加成）/ 矿工雇佣（定时产出私藏料入仓）
            / 矿主购石折扣 / 声望（切出高货积累，提升私藏料价值）
   存档：挂在游戏存档 S.mineOps 上（按矿区名键控），随游戏 save() 持久化。
   平台：window.MineOwner.claim(name) 供发布中心/凭证显式授予矿主权。
================================================================ */
(function(){
'use strict';
/* ---------- 默认配置（可被 mine-owner.config.json 覆盖） ---------- */
var CFG={
  discount:0.9, maxLv:4, upCostBase:2.0, upCostGrowth:1.8,
  greenPerLv:0.005, greenCap:0.02, valuePerLv:0.08,
  minerBase:2, wageMul:0.1, prodMinutes:8,
  pendingCapPerMiner:1, pendingCapMax:6,
  valueBase:0.06, valueRand:0.08,
  fameCap:10, fameValueBonus:0.02, fameGainMinIdx:3,
  gemPool:[
    {maxPrice:1000,    w:{dou:1.0}},
    {maxPrice:3000,    w:{dou:0.7,nuo:0.3}},
    {maxPrice:10000,   w:{dou:0.4,nuo:0.45,bing:0.15}},
    {maxPrice:99999999,w:{nuo:0.55,bing:0.35,boli:0.1}}
  ]
};
var ready=false;
try{
  fetch('mine-owner.config.json',{cache:'no-cache'})
    .then(function(r){return r.ok?r.json():null;})
    .then(function(j){if(j)for(var k in j)if(k!=='comment'&&j[k]!==undefined)CFG[k]=j[k];})
    .catch(function(){})
    .then(function(){boot();});
}catch(e){ setTimeout(boot,50); }
/* 兜底：fetch 挂起或失败也要启动（file:// 下 fetch 直接抛错） */
setTimeout(function(){if(!ready)boot();},1200);

/* ---------- 工具 ---------- */
function keyOf(m){return 'n:'+String(m.name);}
function opOf(m){return S.mineOps&&S.mineOps[keyOf(m)];}
function isOwned(m){return !!(m&&m.ext&&opOf(m));}
function mineByKey(k){
  var name=k.slice(2);
  return allMines().find(function(m){return String(m.name)===name;});
}
function ownedList(){
  if(!S.mineOps)return [];
  return Object.keys(S.mineOps).map(function(k){return {k:k,op:S.mineOps[k],m:mineByKey(k)};})
    .filter(function(x){return x.m;});
}
function greenBonus(op){return Math.min(CFG.greenCap,(op.lv||0)*CFG.greenPerLv);}
function maxMiners(op){return CFG.minerBase+(op.lv||0);}
function dailyWage(m,op){return Math.round(m.price*CFG.wageMul)*(op.miners||0);}
function upCost(m,op){return Math.round(m.price*CFG.upCostBase*Math.pow(CFG.upCostGrowth,op.lv||0));}
function pickGem(price,rnd){
  var pool=CFG.gemPool.find(function(p){return price<=p.maxPrice;})||CFG.gemPool[CFG.gemPool.length-1];
  var tot=0,k;for(k in pool.w)tot+=pool.w[k];
  var r=rnd*tot;
  for(k in pool.w){if(r<pool.w[k])return k;r-=pool.w[k];}
  return 'dou';
}
function saveOps(){try{save();}catch(e){}}

/* ---------- 认领与核心循环 ---------- */
function claim(m){
  if(!m||!m.ext)return false;
  if(!S.mineOps)S.mineOps={};
  var k=keyOf(m);
  if(S.mineOps[k])return false;
  S.mineOps[k]={name:m.name,lv:1,fame:0,miners:0,lastTick:Date.now(),pending:[],wageDay:today(),owed:false,since:Date.now()};
  saveOps();updateBtn();toast('⛏️ 恭喜！你已成为「'+m.name+'」的矿主，可进行经营');
  return true;
}
function produceAll(){
  var now=Date.now(),changed=false;
  ownedList().forEach(function(x){
    var op=x.op,m=x.m;
    if(!op.miners||op.owed||op.wageDay!==today())return;
    var gap=CFG.prodMinutes*60000,per=CFG.prodMinutes*60000;
    var cap=Math.min(CFG.pendingCapMax,op.miners*CFG.pendingCapPerMiner);
    var elapsed=now-(op.lastTick||now);
    var n=Math.min(Math.floor(elapsed/gap),cap-op.pending.length);
    if(n<=0)return;
    for(var i=0;i<n;i++){
      var gem=pickGem(m.price,Math.random());
      var val=Math.round(m.price*(CFG.valueBase+Math.random()*CFG.valueRand)
        *(1+CFG.valuePerLv*(op.lv||0))*(1+Math.min(op.fame||0,CFG.fameCap)*CFG.fameValueBonus));
      op.pending.push({gem:gem,value:Math.max(50,val),t:now,seed:(Math.random()*1e9)|0,size:0.68+Math.random()*0.2});
    }
    op.lastTick=now;changed=true;
  });
  if(changed){saveOps();updateBtn();if(panelOpen())renderPanel();}
}
function chargeWages(){
  var changed=false;
  ownedList().forEach(function(x){
    var op=x.op,m=x.m;
    if(!op.miners)return;
    if(op.wageDay===today())return;
    var wage=dailyWage(m,op);
    if(S.coins>=wage){S.coins-=wage;op.wageDay=today();op.owed=false;changed=true;
      try{renderHeader();}catch(e){}}
    else{op.owed=true;changed=true;}
  });
  if(changed){saveOps();if(panelOpen())renderPanel();}
}
function fameUp(mineId){
  if(!S.mineOps)return;
  var op=Object.keys(S.mineOps).map(function(k){return S.mineOps[k];})
    .find(function(o){return o.name&&allMines().find(function(m){return m.ext&&String(m.name)===o.name&&String(m.id)===String(mineId);});});
  if(op&&op.fame<99){op.fame++;saveOps();}
}

/* ---------- 游戏主逻辑挂钩（包装全局函数，不改主文件） ---------- */
var _refreshStones,_rollover,_openDetail,_finalize;
function hookGame(){
  /* 出绿加成：仅生成本批石阵时临时提升，不污染矿区数据 */
  _refreshStones=refreshStones;
  refreshStones=function(){
    var m=curMine;
    if(m&&m.ext&&!opOf(m))claim(m); /* 入场即认领矿主权 */
    var op=isOwned(m)?opOf(m):null,saved=null;
    if(op){saved=m.green;m.green=Math.min(0.95,m.green+greenBonus(op));}
    try{_refreshStones();}finally{if(saved!==null)m.green=saved;}
  };
  /* 每日工资结算 */
  _rollover=rollover;
  rollover=function(){_rollover();try{chargeWages();}catch(e){}};
  /* 矿主购石折扣：详情页显示矿主价 */
  _openDetail=openDetail;
  openDetail=function(st){
    _openDetail(st);
    if(isOwned(curMine)&&st){
      var d=Math.round(st.cost*CFG.discount);
      document.getElementById("buyBtn").textContent='💰 买下此石（'+fmt(d)+'·矿主价）';
    }
  };
  var bb=document.getElementById("buyBtn"),_buy=bb.onclick;
  bb.onclick=function(){
    var st=detailStone;
    if(isOwned(curMine)&&st){
      var real=st.cost;st.cost=Math.round(real*CFG.discount);
      try{_buy();}finally{st.cost=real;}
    }else _buy();
  };
  /* 声望：在自己矿区切出冰种及以上 → 声望 +1 */
  _finalize=finalize;
  finalize=function(value,early){
    _finalize(value,early);
    try{
      if(cutStone&&S.mineOps){
        var cm=allMines().find(function(m){return String(m.id)===String(cutStone.mineId);});
        var op=cm&&cm.ext?opOf(cm):null;
        if(op&&gemOf(cutStone.quality).idx>=CFG.fameGainMinIdx){
          op.fame++;saveOps();toast('⛏️ 「'+op.name+'」声望 +1（'+op.fame+'）');
          if(panelOpen())renderPanel();
        }
      }
    }catch(e){}
  };
}

/* ---------- 经营面板 UI ---------- */
var modal=null,listEl=null;
function panelOpen(){return modal&&modal.classList.contains('show');}
function buildUI(){
  var st=document.createElement('style');
  st.textContent='#mineOpsBtn{vertical-align:middle;margin-left:8px}'+
    '.mo-card{border:1px solid #2f7d5266;border-radius:12px;padding:12px;margin-bottom:10px;background:rgba(20,34,26,.5)}'+
    '.mo-card h4{margin:0 0 6px;color:var(--gold)}'+
    '.mo-row{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}';
  document.head.appendChild(st);
  var h2s=document.querySelectorAll('h2.st');
  for(var i=0;i<h2s.length;i++){
    if(h2s[i].textContent.indexOf('四大场口')!==-1){
      var b=document.createElement('button');
      b.className='btn ghost small';b.id='mineOpsBtn';
      b.style.display='none';
      b.onclick=openPanel;
      h2s[i].appendChild(b);
      break;
    }
  }
  modal=document.createElement('div');
  modal.className='modal';modal.id='moModal';
  modal.innerHTML='<div class="sheet"><h3>⛏️ 矿主经营</h3><div id="moList"></div>'+
    '<div class="row"><button class="btn ghost small" id="moClose">关闭</button></div></div>';
  document.body.appendChild(modal);
  listEl=modal.querySelector('#moList');
  modal.querySelector('#moClose').onclick=function(){modal.classList.remove('show');};
  modal.addEventListener('click',function(e){if(e.target===modal)modal.classList.remove('show');});
  listEl.addEventListener('click',function(e){
    var b=e.target.closest('button[data-mo]');if(!b)return;
    var k=b.dataset.k,op=S.mineOps[k],m=mineByKey(k);
    if(!op||!m)return;
    var act=b.dataset.mo;
    if(act==='up'){
      var cost=upCost(m,op);
      if(op.lv>=CFG.maxLv){toast('矿脉已到顶级');return;}
      if(S.coins<cost){toast('玉币不足（需 '+fmt(cost)+'）');return;}
      S.coins-=cost;op.lv++;saveOps();renderHeader();renderPanel();
      toast('⛏️ 「'+op.name+'」矿脉升至 Lv.'+op.lv+'（出绿 +'+Math.round(greenBonus(op)*100)+'%）');
    }else if(act==='hire'){
      if(op.miners>=maxMiners(op)){toast('矿工已满（上限随矿脉等级提升）');return;}
      op.miners++;if(!op.lastTick)op.lastTick=Date.now();
      saveOps();renderPanel();toast('⛏️ 已雇佣矿工（'+op.miners+'/'+maxMiners(op)+'），日薪 '+fmt(dailyWage(m,op)));
    }else if(act==='fire'){
      if(op.miners<=0)return;
      op.miners--;saveOps();renderPanel();toast('⛏️ 已遣散一名矿工');
    }else if(act==='claim'){
      var n=op.pending.length;
      if(!n){toast('暂无私藏料可领取');return;}
      op.pending.forEach(function(p){S.inv.push(p);});
      op.pending=[];saveOps();
      try{renderInv();renderStat();}catch(e){}
      renderPanel();updateBtn();
      toast('📦 已领取 '+n+' 块矿工私藏料入仓');
    }else if(act==='pay'){
      var wage=dailyWage(m,op);
      if(!op.owed){toast('今日工资已结清');return;}
      if(S.coins<wage){toast('玉币不足（欠薪 '+fmt(wage)+'）');return;}
      S.coins-=wage;op.owed=false;op.wageDay=today();saveOps();renderHeader();renderPanel();
      toast('⛏️ 工资已补发，矿工复工');
    }
  });
  setInterval(function(){produceAll();updateBtn();if(panelOpen())renderPanel();},30000);
}
function updateBtn(){
  var b=document.getElementById('mineOpsBtn');if(!b)return;
  var list=ownedList();
  b.style.display=list.length?'':'none';
  var pend=0;list.forEach(function(x){pend+=x.op.pending.length;});
  b.textContent=pend?('⛏️ 矿主经营 · 可领 '+pend):'⛏️ 矿主经营';
}
function renderPanel(){
  var list=ownedList();
  if(!list.length){listEl.innerHTML='<div class="empty">还没有产业——入场你自己设计的矿区即可成为矿主。</div>';return;}
  listEl.innerHTML=list.map(function(x){
    var op=x.op,m=x.m;
    var nextMin=op.miners&&!op.owed&&op.wageDay===today()
      ?Math.max(0,Math.ceil(((op.lastTick||0)+CFG.prodMinutes*60000-Date.now())/60000))+' 分钟'
      :'停工';
    return '<div class="mo-card">'+
      '<h4>⛰️ '+op.name+' <span style="font-size:12px;color:var(--gold)">矿脉 Lv.'+op.lv+(op.lv>=CFG.maxLv?'（顶级）':'')+'</span></h4>'+
      '<div class="gv">声望 '+op.fame+' · 矿工 '+op.miners+'/'+maxMiners(op)+' · 日薪 '+fmt(dailyWage(m,op))+
        (op.owed?' <span style="color:#59d98c">（欠薪停工）</span>':'')+'</div>'+
      '<div class="gv">私藏料待领 '+op.pending.length+' · 下一块约 '+nextMin+' · 出绿 +'+Math.round(greenBonus(op)*100)+'% · 购石 '+Math.round(CFG.discount*10)+' 折</div>'+
      '<div class="mo-row">'+
        (op.lv<CFG.maxLv?'<button class="btn small" data-mo="up" data-k="'+x.k+'">⛏️ 升级矿脉（'+fmt(upCost(m,op))+'）</button>':'')+
        '<button class="btn small ghost" data-mo="hire" data-k="'+x.k+'">＋矿工</button>'+
        '<button class="btn small ghost" data-mo="fire" data-k="'+x.k+'">－矿工</button>'+
        '<button class="btn small jade" data-mo="claim" data-k="'+x.k+'">📦 领取私藏料（'+op.pending.length+'）</button>'+
        (op.owed?'<button class="btn small" data-mo="pay" data-k="'+x.k+'">💸 补发工资（'+fmt(dailyWage(m,op))+'）</button>':'')+
      '</div></div>';
  }).join('');
}
function openPanel(){
  if(!S.mineOps)S.mineOps={};
  renderPanel();modal.classList.add('show');
  setTimeout(function(){
    try{Viewer.resize();}catch(e){}
  },50);
}

/* ---------- 对外 API（平台/凭证可显式授予矿主权） ---------- */
window.MineOwner={
  claim:function(nameOrId){
    var m=allMines().find(function(x){return x.ext&&(String(x.name)===String(nameOrId)||String(x.id)===String(nameOrId));});
    return m?claim(m):false;
  },
  list:function(){return ownedList().map(function(x){return {name:x.op.name,lv:x.op.lv,fame:x.op.fame,miners:x.op.miners};});},
  config:CFG
};

/* ---------- 启动 ---------- */
function boot(){
  if(ready)return;
  try{
    /* 注意：S/allMines 是词法全局绑定（let/函数声明），不能通过 window.S 判断 */
    if(typeof S==='undefined'||typeof allMines!=='function'){setTimeout(boot,300);return;}
  }catch(e){setTimeout(boot,300);return;}
  ready=true;
  if(!S.mineOps)S.mineOps={};
  hookGame();buildUI();updateBtn();
  /* 启动即结算：跨天工资 + 离线产出 */
  try{chargeWages();}catch(e){}
  try{produceAll();}catch(e){}
}
})();
